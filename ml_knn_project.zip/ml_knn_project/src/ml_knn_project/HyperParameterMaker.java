package ml_knn_project;

public class HyperParameterMaker {
	static String[] classificationFiles = {"car_data.csv", "segmentation_data.csv", "abalone_data.csv"};
	// KNN Hyper Params
	public void testKNN(int numTestsToRun) {
		for (int tests = 0; tests < numTestsToRun; tests++) {
			
		}
	}
	
}
