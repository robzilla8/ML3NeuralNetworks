package ml_knn_project;

import java.util.ArrayList;

public class CNN extends KNearestNeighbor{
	
	private String timeStamp;

	public CNN(ArrayList<ArrayList<Object>> trainingSet, ArrayList<ArrayList<Object>> testSet, int k,
			ZeroOneLoss zeroOne, MeanSquaredError mse, String timeStamp) {
		super(trainingSet, testSet, k, zeroOne, mse);
		// TODO Auto-generated constructor stub
		algorithmName = "CNN";
		this.timeStamp=timeStamp;
	}

	public void buildModel() {
		buildModel(trainingSet);
	}

	public void buildModel(ArrayList<ArrayList<Object>> ourSet) {


		// one example from each class of the training set is added to KNN classifier
		// the next data point is tested with the classifier

		// if its incorrectly classified, add it to the classifier
		// if not, it is gonna be discarded

		ArrayList<ArrayList<Object>> newSet = new ArrayList<ArrayList<Object>>();


		int N = ourSet.size();    // this includes the class column
		int i = 0;
		ArrayList<Object> pointTested;
		ArrayList<Object> nearestPoint;

		boolean run = true;


		// add the first example
		pointTested = ourSet.get(0);
		newSet.add(pointTested);
		int newSetLength = 1;
		int count = 0; // DELETE
		while (run == true) {
			for (int q = 1; q < ourSet.size(); q++) {
				// Test the points one at a time
				pointTested = ourSet.get(q);
				boolean testInList = true;
				
				// iterate through the points and stop when an element is not in the new set to see if it should be added
				while(testInList && q < ourSet.size() - 1) {
					if(!newSet.contains(pointTested)) {
						testInList = false;
					} else {
						q++;
						pointTested = ourSet.get(q);
					}
				}
				//System.out.printf("pointTested class = %s%n", pointTestedClass);

				// get the nearest data point
				double minDistance = Double.MAX_VALUE;
				int minIndex = -1;
				Distance euclidianDistance = new EuclidianDistance();
				for (int p = 0; p < newSet.size(); p++) {
					double distance = euclidianDistance.getDistance(newSet.get(p), pointTested);
					if (distance < minDistance) {
						minDistance = distance;
						minIndex = p;
					}
				}
				nearestPoint = newSet.get(minIndex);

				// check if that nearest data point is classified incorrectly
				if (!nearestPoint.get(nearestPoint.size() - 1).toString().equals(pointTested.get(pointTested.size() - 1).toString())) {
					newSet.add(pointTested);
				} 

				// handle when it reaches the end of the set
			}
			// Stop running when the size of the new set does not change
			if (newSetLength == newSet.size()) {
				run = false;
			} else {
				newSetLength = newSet.size();
				count++;
			}
		}
		trainingSet = newSet;
		writeCnnToCSV();
		System.out.printf("Ran %d trials through the training set to build condensed nearest neighbor set (size: %d elements)%n", count, newSet.size());
		// check if the class is incorrect
		// remove/tag that data point

	}
	
	public int getModelSize() {
		return trainingSet.size();
	}
	
	private void writeCnnToCSV() {
		CSVReader writer = new CSVReader(timeStamp+"_CNN_Model.csv");
		writer.writer("Begin CNN Model");
		for(int i=0; i<trainingSet.size();i++) {
			String stringToWrite="";
			for(int j=0; j<trainingSet.get(i).size();j++) {
				stringToWrite=stringToWrite+trainingSet.get(i).get(j).toString();
				if(j != trainingSet.get(i).size()-1) {
					stringToWrite=stringToWrite+",";
				}
			}
			writer.writer(stringToWrite);
		}
		
		writer.writer("End CNN Model");
		
		writer.writer("Begin CNN Test Set");
		for(int k=0;k<testSet.size();k++) {
			String stringToWrite2="";
			for(int l=0;l<testSet.get(k).size();l++) {
				stringToWrite2=stringToWrite2+testSet.get(k).get(l).toString();
				if(l!= testSet.get(k).size()-1) {
					stringToWrite2=stringToWrite2+",";
				}
			}
			writer.writer(stringToWrite2);
		}
		writer.writer("End CNN Test Set");
	}
}