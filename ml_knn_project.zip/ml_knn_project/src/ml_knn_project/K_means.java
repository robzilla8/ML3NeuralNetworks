package ml_knn_project;
//this class implements the k_means clustering algorithm, built off of a number given to us by CNN. 
import java.util.ArrayList;
import java.util.Random;
import java.util.HashMap;



public class K_means extends ENN{
//our k-means class, which inherits from CNN.	
	private int numClusters; //keeps track over the number of clusters in the array. 
	private Random rand= new Random();//creates a random number generator for selecting the centeroids initially.
	Distance euclid = new EuclidianDistance();
	private String timeStamp;
	
	
	public K_means(ArrayList<ArrayList<Object>> trainingSet, ArrayList<ArrayList<Object>> testSet, int k,
			ZeroOneLoss zeroOne, MeanSquaredError mse, double validationSetFraction, String timeStamp) {
		super(trainingSet, testSet, k, zeroOne, mse, validationSetFraction, timeStamp);
		this.numClusters=0;//sets the original number of clusters to 0
		this.timeStamp=timeStamp;
		// TODO Auto-Generated constructor for the k-means class
	}

	public void classClusters() {
		//the function that actually makes the cluster for our classification data sets. 
		ArrayList<ArrayList<Object>> cloneSet = new ArrayList<ArrayList<Object>> ();
		for(int i=0;i<trainingSet.size();i++) {
			cloneSet.add(trainingSet.get(i));
		 }
		super.buildModel();//builds the ENN model, which is necessary to get the cluster numbers. 
		numClusters=super.getModelSize();//gets the cluster numbers for the data set.
		//resets the training set back to the original set.
		trainingSet=cloneSet;
		writeTrainingSetToCSV(cloneSet);
		this.makeClusters(trainingSet, numClusters);
	}
	
	public void regressClusters(int clusters) {
		//this function takes prepares the algorithm for a regression data set.  
		numClusters=(int)(0.25*clusters);//the clusters variable passed into the regress clusters uses the 
		writeTrainingSetToCSV(trainingSet);
		makeClusters(trainingSet, numClusters);
	}
	
	public void makeClusters(ArrayList<ArrayList<Object>> trainSet, int numCluster){
		//the actual clustering algorithm, which takes in the training set and makes the clusters. 
		//stores the cluster map for the algorithm
		Timer kmeansTimer= new Timer("Begin Building Kmeans Model");
		HashMap<ArrayList<Object>, Integer> clusterMap= new HashMap<ArrayList<Object>, Integer>();
		ArrayList<ArrayList<Object>>clusterSet = new ArrayList<ArrayList<Object>>();//stores the centeroids for the cluster, which will be returned when the algorithm is done. 
		for(int j=0; j<numCluster;j++) {
			//Initializes the original centeroids to use in the base of the model.
		for(int i=0;i<numCluster;i++){
			clusterSet.add(trainSet.get(rand.nextInt(trainSet.size())));
		}
		  int iter=0; //sets the iterable variable, which determines the number of times we run through the algorithm. 
		  while(iter<(5)) { //goes through the data set and creates the clusters.
			  if(kmeansTimer.checkTimeInMinutes()>(20)) {
				  trainingSet=clusterSet;
				  writeKmeansToCSV();
				  kmeansTimer.stop();
				  return;
			  }
			  for(int l=0;l<trainSet.size();l++) {//goes through and calculates the nearest neighbor between a specific point and a centeroid, then adds that to the specified cluster. 
				  int nearestCluster=clusterSet.indexOf(getNearestNeighbors(1, clusterSet, trainSet.get(l)));
				  clusterMap.put(trainSet.get(l), nearestCluster);
			  }
			  int clusterSize=0;
			  for(int m=0;m<clusterSet.size();m++) {//looks through and gets the number of clusterMaps for a given cluster. 
				  for(int k=0;k<trainSet.size();k++) {
					  int cluster=clusterMap.get(trainSet.get(k));
					  if(cluster==m) {
						  clusterSize++;
					  }
				  }
				  if(clusterSize==0) {//if the cluster does not have any data points, we break.  
					  break;
				  }
				  else {//if the cluster has data points, we take the average of the distance of those data points, and then make the point closest to that position the new centeroid. 
					 int count=0;
					
					  for(ArrayList<Object> key:clusterMap.keySet()){ 
						  ArrayList<Object> instance=key; 
						  if(clusterMap.get(instance)==m){ 
							  if(count<=5){//replaces the centeroid with a new value, and restarts the cycles
								  clusterSet.add(m, instance); clusterSet.remove(m+1); count++; 
							  } 
							  else { 
								  break;}
						  }
						  else { 
							  break; 
						  	} 
					  }
					 
				  }
			  }
			  iter++;
		}
		trainingSet=clusterSet;
		writeKmeansToCSV();
		kmeansTimer.stop();
	}
}
	
	private void writeTrainingSetToCSV(ArrayList<ArrayList<Object>> set) {
		CSVReader writer = new CSVReader(timeStamp+"_Kmeans_TrainingSet.csv");
		writer.writer("Begin Training Set");
		for(int i=0;i<set.size();i++) {
			String stringToWrite="";
			for(int j=0;j<set.get(i).size();j++) {
				stringToWrite=stringToWrite+set.get(i).get(j).toString();
				if(j != set.get(i).size()-1) {
					stringToWrite=stringToWrite+",";
				}
			}
			writer.writer(stringToWrite);
		}
		
		writer.writer("End Training Set");
		
	}
	
	private void writeKmeansToCSV() {
		CSVReader writer = new CSVReader(timeStamp +"_Kmeans_Model.csv");
		writer.writer("Begin Kmeans model");
		for(int i=0;i<trainingSet.size();i++) {
			String stringToWrite="";
			for(int j=0;j<trainingSet.get(i).size();j++) {
				stringToWrite=stringToWrite+trainingSet.get(i).get(j).toString();
				if(j != trainingSet.get(i).size()-1) {
					stringToWrite=stringToWrite+",";
				}
			}
			writer.writer(stringToWrite);
		}
		
		writer.writer("End Kmeans model");
		
		writer.writer("Begin Kmeans Test Set");
		for(int k=0;k<testSet.size();k++) {
			String stringToWrite2="";
			for(int l=0;l<testSet.get(k).size();l++) {
				stringToWrite2=stringToWrite2+testSet.get(k).get(l).toString();
				if(l!= testSet.get(k).size()-1) {
					stringToWrite2=stringToWrite2+",";
				}
			}
			writer.writer(stringToWrite2);
		}
		writer.writer("End Kmeans Test Set");
	}
}